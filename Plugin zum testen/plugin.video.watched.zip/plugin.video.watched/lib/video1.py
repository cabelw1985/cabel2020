import video
video.main()